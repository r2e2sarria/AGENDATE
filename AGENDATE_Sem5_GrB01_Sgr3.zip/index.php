<?php
include 'templates/head.php';
?>
<div class="mainbox">
    <br>
    <img src="images/logo1.png" alt="Logo de Agendate" class="logo1">
    <label for="subtit">SIEMPRE DISPUESTOS A ESCUCHARTE</label>
    <?php include 'templates/menu.php'; ?>
</div>
</body>

</html>
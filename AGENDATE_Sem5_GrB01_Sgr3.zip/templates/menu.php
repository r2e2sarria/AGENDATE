<br>
<div class="menu">
    <div class="tac pointer">
        <a href="index.php">
            <i class="fa-solid fa-house"></i><br>
            <span class="fs04 tac">INICIO</span>
        </a>
    </div>
    <div class="tac pointer">
        <a href="consultar.php">
            <i class="fa-solid fa-magnifying-glass"></i><br>
            <span class="fs04 tac">BUSCAR</span>
        </a>
    </div>
    <div class="tac pointer">
        <a href="creaCita.php">
            <i class="fa-solid fa-square-plus"></i><br>
            <span class="fs04 tac">CREAR</span>
        </a>
    </div>
</div>
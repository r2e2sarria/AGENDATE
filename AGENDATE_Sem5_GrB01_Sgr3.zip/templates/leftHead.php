<div class="leftHead">
    <img src="images/toplogo.png" alt="Logo de Agendate" class="logo2">
</div>
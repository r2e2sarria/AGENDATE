<?php
// 
// Pantalla de entrada al proceso de creacion de cita
// 
include 'templates/head.php';
?>
<div class="mainbox">
    <br>
    <?php include 'templates/leftHead.php'; ?>
    <img src="images/ok.png" alt="Reserva exitosa" class="okpng">
    <label for="msg1">EL TURNO FUE CREADO</label>


    <?php include 'templates/menuadm.php'; ?>
</div>
</body>

</html>
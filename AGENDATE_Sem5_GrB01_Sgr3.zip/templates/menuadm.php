<br>
<div class="menu menuadm">
    <div class="tac pointer">
        <a href="admon.php">
            <i class="fa-solid fa-house"></i><br>
            <span class="fs04 tac">INICIO</span>
        </a>
    </div>
    <div class="tac pointer">
        <a href="consultAgenda.php">
            <i class="fa-solid fa-magnifying-glass"></i><br>
            <span class="fs04 tac">LISTAR</span>
        </a>
    </div>
    <div class="tac pointer">
        <a href="creaAgenda.php">
            <i class="fa-solid fa-square-plus"></i><br>
            <span class="fs04 tac">AGENDA</span>
        </a>
    </div>
    <div class="tac pointer">
        <a href="perfil.php">
            <i class="fa-solid fa-user"></i>
            <span class="fs04 tac">PROFILE</span>
        </a>
    </div>
</div>